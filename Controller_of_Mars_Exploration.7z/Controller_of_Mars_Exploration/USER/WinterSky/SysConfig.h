#ifndef _SYSCONFIG_H_
#define	_SYSCONFIG_H_

#include <stm32f10x.h>

void RCC_Config(void);
void NVIC_Config(void);


#endif
