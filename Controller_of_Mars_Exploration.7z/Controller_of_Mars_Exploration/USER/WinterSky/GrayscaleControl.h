#ifndef _GRAYSCALECONTROL_H_
#define _GRAYSCALECONTROL_H_

#include <stm32f10x.h>

extern u16 iGrayF, iGrayB;

void grayLoadValue(void);



#endif
